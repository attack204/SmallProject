package com.mybatis.bean;

import lombok.Data;

@Data
public class Account {
    private Integer id;
    private String userName;
    private String password;
}
